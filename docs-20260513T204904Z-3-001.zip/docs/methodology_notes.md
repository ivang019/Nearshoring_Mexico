# Methodology Notes

## Project

Market Opportunity Analytics for Nearshoring-Driven Industrial B2B Services in Mexico.

## Current Stage

The project is currently in an early data-building stage. The first completed module processes INEGI Economic Census data from SAIC and creates the initial municipal manufacturing datasets.

At this stage, the project does not estimate nearshoring effects, build a predictive model, or create a final opportunity score. The current objective is to build a clean and reproducible data foundation.

## Sprint 1 Objective

Sprint 1 focuses on constructing a municipal-level manufacturing capacity database using INEGI Economic Census data.

The purpose of this module is to measure existing manufacturing capacity across Mexican municipalities. This serves as a first proxy for potential industrial demand for B2B services.

## Source

The input file used in this sprint is:

- `SAIC_INEGI.csv`

The file was downloaded from INEGI's SAIC system for Economic Censuses.

The processed data includes the following census years:

- 2003
- 2008
- 2013
- 2018
- 2023

## Raw File Structure

The original SAIC file does not start directly with the data table. It contains metadata rows before the actual header row.

The processing script detects the real header row by searching for the row that contains fields such as:

- `Año Censal`
- `Entidad`
- `Municipio`
- `Actividad económica`

After detecting the correct header row, the script reads the full file using those names as column headers.

## Column Cleaning

Original column names were standardized to make the dataset easier to use in Python.

The cleaning process:

- converts names to lowercase;
- removes accents;
- replaces spaces with underscores;
- removes special characters;
- reduces repeated underscores;
- creates shorter analytical names for key variables.

For example:

- `Año Censal` becomes `year`.
- `UE Unidades económicas` becomes `establishments`.
- `H001A Personal ocupado total` becomes `employment`.
- `A131A Valor agregado censal bruto (millones de pesos)` becomes `value_added`.

## Geographic Processing

The original `Entidad` and `Municipio` fields include both numeric codes and names.

The script separates them into:

- `entidad_id`
- `entidad_name`
- `municipio_id`
- `municipio_name`

A municipal geographic key is created as:

`geo_key = entidad_id + municipio_id`

For example:

`01` + `001` = `01001`

This key will be useful for merging additional municipal-level sources later in the project.

## Economic Activity Processing

Economic activities are identified from the `Actividad económica` field.

The script extracts:

- `scian_code`
- `scian_description`
- `scian_level`

Examples:

- `Sector 31-33 Industrias manufactureras` becomes:
  - `scian_code = 31-33`
  - `scian_description = Industrias manufactureras`
  - `scian_level = sector`

- `Subsector 311 Industria alimentaria` becomes:
  - `scian_code = 311`
  - `scian_description = Industria alimentaria`
  - `scian_level = subsector`

## Manufacturing Filter

Manufacturing activity is identified using:

- the aggregate SCIAN sector `31-33`, and
- SCIAN activity codes starting with `31`, `32`, or `33`.

This filter creates the municipal manufacturing dataset used in Sprint 1.

## Employment Variable

The employment variable used in the final datasets is:

`H001A Personal ocupado total`

This is the correct total employment variable.

The raw SAIC file also includes:

- `H001B Personal ocupado total, hombres`
- `H001C Personal ocupado total, mujeres`

These variables represent male and female employment separately and are not used as total employment.

## Output Datasets

Sprint 1 creates three processed files:

- `municipality_industrial_base.csv`
- `municipality_industrial_summary.csv`
- `validation_report.csv`

## municipality_industrial_base.csv

This is the detailed manufacturing dataset.

Its unit of observation is:

`year × municipality × manufacturing SCIAN activity`

The file keeps both sector and subsector observations to allow more flexible analysis of manufacturing structure.

## municipality_industrial_summary.csv

This is the municipal manufacturing summary dataset.

Its unit of observation is:

`year × municipality`

The summary uses only the sector-level manufacturing record:

`31-33 Industrias manufactureras`

This decision avoids double counting across SCIAN aggregation levels.

## Avoiding Double Counting

The raw data contains records at different SCIAN aggregation levels. For the same municipality and year, the file may contain both:

- the total manufacturing sector record, and
- several manufacturing subsector records.

Adding all of these rows together would duplicate manufacturing activity.

For this reason, the detailed base preserves multiple SCIAN levels, but the municipal summary uses only the aggregate manufacturing sector record.

## Derived Indicators

The processing script creates the following derived indicators:

- `avg_employment_per_establishment = employment / establishments`
- `value_added_per_worker = value_added / employment`
- `income_per_worker = total_income / employment`
- `investment_per_worker = investment / employment`

For the municipal summary, equivalent manufacturing-level indicators are created:

- `avg_manufacturing_employment_per_establishment`
- `manufacturing_value_added_per_worker`
- `manufacturing_income_per_worker`

The script uses safe division to avoid division by zero.

## Validation

A basic validation report is created as `validation_report.csv`.

This file records checks such as:

- number of rows in the processed datasets;
- number of columns;
- years available;
- number of entities;
- number of municipalities;
- employment variable used;
- SCIAN levels available;
- confirmation that the municipal summary avoids double counting.

## Interpretation

The current module measures existing municipal manufacturing capacity.

It should be interpreted as a descriptive market intelligence input, not as a direct measure of nearshoring inflows.

Municipalities with stronger manufacturing capacity may represent more relevant markets for industrial B2B services, but additional data is needed to assess broader market opportunity.

## Limitations

The current version has several limitations:

- It does not measure nearshoring causally.
- It does not identify new investment announcements.
- It does not include DENUE or direct measures of B2B service supply.
- It does not include IMMEX, exports, FDI, talent, logistics, infrastructure, or risk variables.
- Monetary variables are in millions of pesos and may require additional treatment for intertemporal comparisons.
- The Economic Census is quinquennial, not annual.

## Next Steps

The next steps are:

1. Validate and explore the municipal manufacturing datasets.
2. Build an initial industrial capacity ranking for 2023.
3. Identify manufacturing subsectors that are conceptually relevant to nearshoring-related activity.
4. Incorporate DENUE to measure local B2B service supply.
5. Combine manufacturing capacity and B2B service supply indicators.
6. Develop a preliminary municipal opportunity typology.
