# Data Dictionary

This document describes the main processed datasets created in Sprint 1 of the project.

The current processed files are:

- `municipality_industrial_base.csv`
- `municipality_industrial_summary.csv`
- `validation_report.csv`

## File: municipality_industrial_base.csv

This file contains municipal-level manufacturing data by year, municipality, and SCIAN manufacturing activity.

Unit of observation:

`year × municipality × manufacturing SCIAN activity`

| Column | Description | Unit | Source / Calculation |
|---|---|---|---|
| `year` | Census year | Year | `Año Censal` |
| `entidad_id` | Federal entity code | Text | Extracted from `Entidad` |
| `entidad_name` | Federal entity name | Text | Extracted from `Entidad` |
| `municipio_id` | Municipality code within the federal entity | Text | Extracted from `Municipio` |
| `municipio_name` | Municipality name | Text | Extracted from `Municipio` |
| `geo_key` | Municipal geographic key | Text | `entidad_id + municipio_id` |
| `scian_code` | SCIAN economic activity code | Text | Extracted from `Actividad económica` |
| `scian_description` | SCIAN activity description | Text | Extracted from `Actividad económica` |
| `scian_level` | SCIAN aggregation level | Text | Derived from the activity label |
| `establishments` | Number of economic units | Count | `UE Unidades económicas` |
| `employment` | Total employed personnel | Persons | `H001A Personal ocupado total` |
| `value_added` | Gross census value added | Millions of pesos | `A131A Valor agregado censal bruto` |
| `total_income` | Total income | Millions of pesos | `A800A Total de ingresos` |
| `total_expenses` | Total expenses | Millions of pesos | `A700A Total de gastos` |
| `investment` | Total investment | Millions of pesos | `A211A Inversión total` |
| `gross_fixed_capital_formation` | Gross fixed capital formation | Millions of pesos | `A221A Formación bruta de capital fijo` |
| `avg_employment_per_establishment` | Average employment per establishment | Persons per establishment | `employment / establishments` |
| `value_added_per_worker` | Value added per worker | Millions of pesos per worker | `value_added / employment` |
| `income_per_worker` | Income per worker | Millions of pesos per worker | `total_income / employment` |
| `investment_per_worker` | Investment per worker | Millions of pesos per worker | `investment / employment` |

## File: municipality_industrial_summary.csv

This file contains municipal-level manufacturing totals by year.

Unit of observation:

`year × municipality`

This file uses only the sector-level manufacturing record `31-33 Industrias manufactureras` to avoid double counting across SCIAN aggregation levels.

| Column | Description | Unit | Source / Calculation |
|---|---|---|---|
| `year` | Census year | Year | `Año Censal` |
| `entidad_id` | Federal entity code | Text | Extracted from `Entidad` |
| `entidad_name` | Federal entity name | Text | Extracted from `Entidad` |
| `municipio_id` | Municipality code within the federal entity | Text | Extracted from `Municipio` |
| `municipio_name` | Municipality name | Text | Extracted from `Municipio` |
| `geo_key` | Municipal geographic key | Text | `entidad_id + municipio_id` |
| `total_manufacturing_establishments` | Total manufacturing economic units | Count | Sector `31-33`, `UE Unidades económicas` |
| `total_manufacturing_employment` | Total manufacturing employment | Persons | Sector `31-33`, `H001A Personal ocupado total` |
| `total_manufacturing_value_added` | Total manufacturing gross census value added | Millions of pesos | Sector `31-33`, `A131A Valor agregado censal bruto` |
| `total_manufacturing_income` | Total manufacturing income | Millions of pesos | Sector `31-33`, `A800A Total de ingresos` |
| `total_manufacturing_expenses` | Total manufacturing expenses | Millions of pesos | Sector `31-33`, `A700A Total de gastos` |
| `total_manufacturing_investment` | Total manufacturing investment | Millions of pesos | Sector `31-33`, `A211A Inversión total` |
| `total_manufacturing_gross_fixed_capital_formation` | Manufacturing gross fixed capital formation | Millions of pesos | Sector `31-33`, `A221A Formación bruta de capital fijo` |
| `avg_manufacturing_employment_per_establishment` | Average manufacturing employment per establishment | Persons per establishment | `total_manufacturing_employment / total_manufacturing_establishments` |
| `manufacturing_value_added_per_worker` | Manufacturing value added per worker | Millions of pesos per worker | `total_manufacturing_value_added / total_manufacturing_employment` |
| `manufacturing_income_per_worker` | Manufacturing income per worker | Millions of pesos per worker | `total_manufacturing_income / total_manufacturing_employment` |
| `number_of_manufacturing_scian_activities` | Number of observed manufacturing SCIAN activities | Count | Count of unique disaggregated manufacturing SCIAN codes by municipality and year |

## File: validation_report.csv

This file provides a basic validation summary of the processed datasets.

| Column | Description |
|---|---|
| `check` | Name of the validation check |
| `result` | Result of the validation check |

Typical checks include:

- number of rows in `municipality_industrial_base.csv`;
- number of columns in `municipality_industrial_base.csv`;
- number of rows in `municipality_industrial_summary.csv`;
- number of columns in `municipality_industrial_summary.csv`;
- years available;
- number of entities;
- number of municipalities;
- employment variable used;
- SCIAN levels available;
- confirmation that double counting was avoided in the municipal summary.

## Notes

All monetary variables are expressed in millions of pesos as reported in the original SAIC file.

The current datasets should be interpreted as descriptive measures of existing manufacturing capacity. They do not directly measure nearshoring inflows or causal effects.
